package test2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Frame3 extends JFrame {
	private static class LabelFactory {
		// 라벨 생성 메소드
		public static JLabel updateLabel(String updateLabel) {
			JLabel newLabel = new JLabel(updateLabel);
			newLabel.setHorizontalTextPosition(JLabel.CENTER);
			newLabel.setVerticalTextPosition(JLabel.CENTER);

			return newLabel;
		}
	}

	// 당첨번호와 사용자번호를 비교하는 메소드
	public void correctCircle(List<Integer> lottoNum, List<String[]> lottoNumArrayList, int pnlNum) {
		int[] userLottoNum = pnlLottoNum(lottoNumArrayList, pnlNum);
		for (int i = 0; i < lottoNum.size(); i++) {
			for (int j = 0; j < userLottoNum.length; j++) {
				if ( lottoNum.get(i) == userLottoNum[j] ) {
					
				}
			}
		}
	}

		// lottonum과 lottoNumarray의 배열 값들을 비교할 수 있는 메서드

		// IF 번호가 같지 않으면 검정색 공으로 바뀌어 출력


	private JTextField textField;

	public List<String[]> readLottoNums() {
		File dataFolder = new File("./\\Lotto");
		File lottofile = new File(dataFolder, "lotto.txt");
		List<String[]> newName = new ArrayList<>();
		StringBuilder newBuilder = new StringBuilder(); // 파일리더는 한 단어씩 받아오기 때문에 단어들을 합해줄 StringBuilder가 필요
		// 메모장에 저장된 값을 불러와서
		// 리스트에 저장한 후
		// 그 리스트를 불러와서 이미지 레이블에 출력할 예정

		FileReader reading = null;
		try {
			reading = new FileReader(lottofile);

			// 인트형으로 받아서 캐릭터형으로 캐스팅
			int ch;
			while ((ch = reading.read()) != -1) {
				newBuilder.append((char) ch); // 아스키 코드(문자형)

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reading != null) {
				try {
					reading.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		String builderString = newBuilder.toString();

		// 스플릿 메서드를 통해 newBuilder의 문자열을 [기준으로 쪼개서 string 배열에 넣어줌
		// 대괄호들 []을 /로 번경해줌
		builderString = builderString.replaceAll("\\]", "/");
		builderString = builderString.replaceAll("\\[", "/");
//		System.out.println(builderString);
//		split를 /로 쪼갬 
		String[] split = builderString.split("/");
//		System.out.println(Arrays.toString(split));
//		System.out.println(split[1].toString());
//		1, 3, 5, 7, 9의 값을 출력
		for (int i = 0; i < 5; i++) {
			newName.add(split[i * 2 + 1].split(", "));
		} // newName 메소드 활용을 위해 return
		return newName;

	}

	// 파일과 원하는 패널 번호를 파라미터로 입력받아 패널안의 문자열을 인트배열로 변환
	public int[] pnlLottoNum(List<String[]> lottoNumArrayList,int pnlNum) {
		int[] arr = new int[6];
		for(int i =0; i <lottoNumArrayList.size(); i++) {
			arr[i] = Integer.parseInt(lottoNumArrayList.get(pnlNum)[i]);
			}
		
		return arr;
	}
	
	
	// 패널 출력 공 for문
	// 패널 출력 공 번호
	// 1~10 : 노랑
	// 11~20 : 빨강
	// 21~30 : 초록
	// 31~40 : 파랑
	// 41~50 : 핑크
	// 낙첨 : 검정

	// 숫자 범위 별로 이미지 출력
	public ImageIcon chooseIcon(int num) {
		if (num <= 10)
			return new ImageIcon(Frame3.class.getResource("/image/노랑.png"));
		else if (num <= 20)
			return new ImageIcon(Frame3.class.getResource("/image/초록.png"));
		else if (num <= 30)
			return new ImageIcon(Frame3.class.getResource("/image/파랑.png"));
		else if (num <= 40)
			return new ImageIcon(Frame3.class.getResource("/image/핑크.png"));
		else if (num <= 45)
			return new ImageIcon(Frame3.class.getResource("/image/빨강.png"));
		return new ImageIcon(Frame3.class.getResource("/image/검정.png"));
	}

	public Frame3() {
		super("로또 당첨 확인창");
		// 기본 패널
		JPanel Panel1 = new JPanel();

		List<String[]> lottoNumArrayList = readLottoNums();

		System.out.println(Arrays.toString(lottoNumArrayList.get(0)));
//		System.out.println(lottoNumArrayList.get(0)[0]);

		Panel1.setLayout(new GridLayout(6, 0, 3, 3)); // 패널이 6행으로 나뉨
		getContentPane().add(Panel1, BorderLayout.NORTH); // 맨 위의 패널의 값들을 보이게 함

		getContentPane().add(Panel1); // 전체 큰 패널에 패널 추가 기능

		setSize(700, 700);
//		JPanel panel = new JPanel();

		// 아이콘 이미지 저장
//		ImageIcon icon = new ImageIcon(Frame3.class.getResource("/image/검정.png"));
//		ImageIcon icon2 = new ImageIcon(Frame3.class.getResource("/image/노랑.png"));
//		ImageIcon icon3 = new ImageIcon(Frame3.class.getResource("/image/빨강.png"));
//		ImageIcon icon4 = new ImageIcon(Frame3.class.getResource("/image/초록.png"));
//		ImageIcon icon5 = new ImageIcon(Frame3.class.getResource("/image/파랑.png"));
//		ImageIcon icon6 = new ImageIcon(Frame3.class.getResource("/image/핑크.png"));

		// 난수 생성
		Random r = new Random();

		// 리스트로 저장해서 값들을 저장하고 레이블에 텍스트로 출력하기 위함
		List<Integer> lottoNumList = new ArrayList<>(); // lbl1~5까지 추가할 난수 생성 리스트
		Set<Integer> lotto = new TreeSet<>(); // 중복제거

		while (lotto.size() < 6) { // integer lotto 숫자를 확인해서 아래 중복을 허용하지 않고 set에 삽입
			lotto.add(r.nextInt(45) + 1); // list는 size로, set은 index값이 없음

		}
		for (Integer n : lotto) { // 삽입한 set 값을 lottoNumList에 넣어줌
			lottoNumList.add(n); // 해당 리스트를 이용해서 원하는 인덱스 값을 쉽게 사용 가능
		}
//		System.out.println(lottoNumList); // lottoNumList는 랜덤 난수 1~45개중 6개 출력값임

//		List<String[]> lottoNumArrayList = readLottoNums();
//		System.out.println(Arrays.toString(lottoNumArrayList.get(0)));

		// 패널 6개로 나눔
		JPanel panel_1 = new JPanel();
		Panel1.add(panel_1);

		JPanel panel_2 = new JPanel();
		Panel1.add(panel_2);

		JPanel panel_3 = new JPanel();
		Panel1.add(panel_3);

		JPanel panel_4 = new JPanel();
		Panel1.add(panel_4);

		JPanel panel_5 = new JPanel();
		Panel1.add(panel_5);

		JPanel panel_6 = new JPanel();
		Panel1.add(panel_6);

		// updateLabel 메소드 생성
		// 패널의 첫번째 행 레이블 6개 추가
		JLabel lbl1 = LabelFactory.updateLabel(lottoNumList.get(0).toString());
		JLabel lbl2 = LabelFactory.updateLabel(lottoNumList.get(1).toString());
		JLabel lbl3 = LabelFactory.updateLabel(lottoNumList.get(2).toString());
		JLabel lbl4 = LabelFactory.updateLabel(lottoNumList.get(3).toString());
		JLabel lbl5 = LabelFactory.updateLabel(lottoNumList.get(4).toString());
		JLabel lbl6 = LabelFactory.updateLabel(lottoNumList.get(5).toString());

		lbl1.setOpaque(true); // 투명도

//		 패널의 두번째 행 레이블 6개 추가
		System.out.println(lottoNumList.contains(lottoNumArrayList.get(0)[0]));
		JLabel lblNewLabel_1 = LabelFactory.updateLabel(lottoNumArrayList.get(0)[0]);
		JLabel lblNewLabel_2 = LabelFactory.updateLabel(lottoNumArrayList.get(0)[1]);
		JLabel lblNewLabel_3 = LabelFactory.updateLabel(lottoNumArrayList.get(0)[2]);
		JLabel lblNewLabel_4 = LabelFactory.updateLabel(lottoNumArrayList.get(0)[3]);
		JLabel lblNewLabel_5 = LabelFactory.updateLabel(lottoNumArrayList.get(0)[4]);
		JLabel lblNewLabel_6 = LabelFactory.updateLabel(lottoNumArrayList.get(0)[5]);

//		 패널의 세번째 행 레이블 6개 추가
		JLabel lblNewLabel_11 = LabelFactory.updateLabel(lottoNumArrayList.get(1)[0]);
		JLabel lblNewLabel_22 = LabelFactory.updateLabel(lottoNumArrayList.get(1)[1]);
		JLabel lblNewLabel_33 = LabelFactory.updateLabel(lottoNumArrayList.get(1)[2]);
		JLabel lblNewLabel_44 = LabelFactory.updateLabel(lottoNumArrayList.get(1)[3]);
		JLabel lblNewLabel_55 = LabelFactory.updateLabel(lottoNumArrayList.get(1)[4]);
		JLabel lblNewLabel_66 = LabelFactory.updateLabel(lottoNumArrayList.get(1)[5]);

//		 패널의 네번째 행 레이블 6개 추가
		JLabel lblNewLabel_111 = LabelFactory.updateLabel(lottoNumArrayList.get(2)[0]);
		JLabel lblNewLabel_222 = LabelFactory.updateLabel(lottoNumArrayList.get(2)[1]);
		JLabel lblNewLabel_333 = LabelFactory.updateLabel(lottoNumArrayList.get(2)[2]);
		JLabel lblNewLabel_444 = LabelFactory.updateLabel(lottoNumArrayList.get(2)[3]);
		JLabel lblNewLabel_555 = LabelFactory.updateLabel(lottoNumArrayList.get(2)[4]);
		JLabel lblNewLabel_666 = LabelFactory.updateLabel(lottoNumArrayList.get(2)[5]);

//		 패널의 다섯번째 행 레이블 6개 추가
		JLabel lblNewLabel_1111 = LabelFactory.updateLabel(lottoNumArrayList.get(3)[0]);
		JLabel lblNewLabel_2222 = LabelFactory.updateLabel(lottoNumArrayList.get(3)[1]);
		JLabel lblNewLabel_3333 = LabelFactory.updateLabel(lottoNumArrayList.get(3)[2]);
		JLabel lblNewLabel_4444 = LabelFactory.updateLabel(lottoNumArrayList.get(3)[3]);
		JLabel lblNewLabel_5555 = LabelFactory.updateLabel(lottoNumArrayList.get(3)[4]);
		JLabel lblNewLabel_6666 = LabelFactory.updateLabel(lottoNumArrayList.get(3)[5]);

//		 패널의 여섯번째 행 레이블 6개 추가
		JLabel lblNewLabel_11111 = LabelFactory.updateLabel(lottoNumArrayList.get(4)[0]);
		JLabel lblNewLabel_22222 = LabelFactory.updateLabel(lottoNumArrayList.get(4)[1]);
		JLabel lblNewLabel_33333 = LabelFactory.updateLabel(lottoNumArrayList.get(4)[2]);
		JLabel lblNewLabel_44444 = LabelFactory.updateLabel(lottoNumArrayList.get(4)[3]);
		JLabel lblNewLabel_55555 = LabelFactory.updateLabel(lottoNumArrayList.get(4)[4]);
		JLabel lblNewLabel_66666 = LabelFactory.updateLabel(lottoNumArrayList.get(4)[5]);

//		JLabel lblNewLabel_2 = new JLabel();
//		lblNewLabel_2.setText(lottoNumArrayList.get(0)[1]);
//		lblNewLabel_2.setHorizontalTextPosition(JLabel.CENTER);
//		lblNewLabel_2.setVerticalTextPosition(JLabel.CENTER);
//
//		JLabel lblNewLabel_3 = new JLabel();
//		lblNewLabel_3.setText(lottoNumArrayList.get(0)[2]);
//		lblNewLabel_3.setHorizontalTextPosition(JLabel.CENTER);
//		lblNewLabel_3.setVerticalTextPosition(JLabel.CENTER);
//
//		JLabel lblNewLabel_4 = new JLabel();
//		lblNewLabel_4.setText(lottoNumArrayList.get(0)[3]);
//		lblNewLabel_4.setHorizontalTextPosition(JLabel.CENTER);
//		lblNewLabel_4.setVerticalTextPosition(JLabel.CENTER);
//
//		JLabel lblNewLabel_5 = new JLabel();
//		lblNewLabel_5.setText(lottoNumArrayList.get(0)[4]);
//		lblNewLabel_5.setHorizontalTextPosition(JLabel.CENTER);
//		lblNewLabel_5.setVerticalTextPosition(JLabel.CENTER);
//
//		JLabel lblNewLabel_6 = new JLabel();
//		lblNewLabel_6.setText(lottoNumArrayList.get(0)[5]);
//		lblNewLabel_6.setHorizontalTextPosition(JLabel.CENTER);
//		lblNewLabel_6.setVerticalTextPosition(JLabel.CENTER);

		// 1번째 패널에 lottoNumList의 랜덤수에 따른 아이콘 넣기

		lbl1.setIcon(chooseIcon(lottoNumList.get(0)));
		lbl2.setIcon(chooseIcon(lottoNumList.get(1)));
		lbl3.setIcon(chooseIcon(lottoNumList.get(2)));
		lbl4.setIcon(chooseIcon(lottoNumList.get(3)));
		lbl5.setIcon(chooseIcon(lottoNumList.get(4)));
		lbl6.setIcon(chooseIcon(lottoNumList.get(5)));

//		 2번째 패널에 lottoNumArrayList에 따른 아이콘 넣기
		lblNewLabel_1.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(0)[0])));
		lblNewLabel_2.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(0)[1])));
		lblNewLabel_3.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(0)[2])));
		lblNewLabel_4.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(0)[3])));
		lblNewLabel_5.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(0)[4])));
		lblNewLabel_6.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(0)[5])));

//		 3번째 패널에 lottoNumArrayList에 따른 아이콘 넣기
		lblNewLabel_11.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(1)[0])));
		lblNewLabel_22.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(1)[1])));
		lblNewLabel_33.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(1)[2])));
		lblNewLabel_44.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(1)[3])));
		lblNewLabel_55.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(1)[4])));
		lblNewLabel_66.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(1)[5])));
//		 4번째 패널에 lottoNumArrayList에 따른 아이콘 넣기
		lblNewLabel_111.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(2)[0])));
		lblNewLabel_222.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(2)[1])));
		lblNewLabel_333.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(2)[2])));
		lblNewLabel_444.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(2)[3])));
		lblNewLabel_555.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(2)[4])));
		lblNewLabel_666.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(2)[5])));
//		 5번째 패널에 lottoNumArrayList에 따른 아이콘 넣기
		lblNewLabel_1111.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(3)[0])));
		lblNewLabel_2222.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(3)[1])));
		lblNewLabel_3333.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(3)[2])));
		lblNewLabel_4444.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(3)[3])));
		lblNewLabel_5555.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(3)[4])));
		lblNewLabel_6666.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(3)[5])));
//		 6번째 패널에 lottoNumArrayList에 따른 아이콘 넣기
		lblNewLabel_11111.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(4)[0])));
		lblNewLabel_22222.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(4)[1])));
		lblNewLabel_33333.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(4)[2])));
		lblNewLabel_44444.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(4)[3])));
		lblNewLabel_55555.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(4)[4])));
		lblNewLabel_66666.setIcon(chooseIcon(Integer.parseInt(lottoNumArrayList.get(4)[5])));

		// 각 패널에 해당 레이블 추가
		// 첫번째 패널
		panel_1.add(lbl1);
		panel_1.add(lbl2);
		panel_1.add(lbl3);
		panel_1.add(lbl4);
		panel_1.add(lbl5);
		panel_1.add(lbl6);
//		 두번째 패널
		panel_2.add(lblNewLabel_1);
		panel_2.add(lblNewLabel_2);
		panel_2.add(lblNewLabel_3);
		panel_2.add(lblNewLabel_4);
		panel_2.add(lblNewLabel_5);
		panel_2.add(lblNewLabel_6);
//		 세번째 패널
		panel_3.add(lblNewLabel_11);
		panel_3.add(lblNewLabel_22);
		panel_3.add(lblNewLabel_33);
		panel_3.add(lblNewLabel_44);
		panel_3.add(lblNewLabel_55);
		panel_3.add(lblNewLabel_66);
//		 네번째 패널
		panel_4.add(lblNewLabel_111);
		panel_4.add(lblNewLabel_222);
		panel_4.add(lblNewLabel_333);
		panel_4.add(lblNewLabel_444);
		panel_4.add(lblNewLabel_555);
		panel_4.add(lblNewLabel_666);
//		 다섯번째 패널
		panel_5.add(lblNewLabel_1111);
		panel_5.add(lblNewLabel_2222);
		panel_5.add(lblNewLabel_3333);
		panel_5.add(lblNewLabel_4444);
		panel_5.add(lblNewLabel_5555);
		panel_5.add(lblNewLabel_6666);
//		 여섯번째 패널
		panel_6.add(lblNewLabel_11111);
		panel_6.add(lblNewLabel_22222);
		panel_6.add(lblNewLabel_33333);
		panel_6.add(lblNewLabel_44444);
		panel_6.add(lblNewLabel_55555);
		panel_6.add(lblNewLabel_66666);

//		frame3 correct = new correct();
		
		
		int number = 0;
		textField = new JTextField(10);

		for (int i = 0; i < number; i++) {
			JButton btn = new JButton();
//			panel.add(btn);
			setDefaultCloseOperation(EXIT_ON_CLOSE);

			Panel1.revalidate();
			// 레이아웃 새로 계산
			Panel1.repaint();
			// 변경된 지점 새로 그리기
		}
	}

	public class TextLabel extends JLabel {

		public TextLabel(int number) {
			setIcon(new ImageIcon(Frame3.class.getResource("/image/검정.png")));//
			setHorizontalTextPosition(JLabel.CENTER); // 레이블의 텍스트 가로 부분을 가운데로 고정
			setVerticalTextPosition(JLabel.CENTER);// 레이블의 텍스트 세로 부분을 가운데로 고정
			setFont(new Font("Serif", Font.BOLD, 20)); // 폰트 설정
			setForeground(Color.WHITE); // 글자색깔 설정
			setText(String.valueOf(number)); // 글자 설정
			setHorizontalAlignment(SwingConstants.CENTER); // 레이블 자체의 수평 위치를 중간으로
			setVerticalAlignment(SwingConstants.CENTER); // 레이블 자체의 수직 위치를 중간으로
		}
	}

	public static void main(String[] args) {

		new Frame3().setVisible(true);

//		Frame3 frame = new Frame3();
//		frame.readLottoNums();
		// String[] line = frame.readLottoNums();
//		System.out.println(Arrays.toString(line));
	}
}

// 난수랑 이미지를 연결?
//			JFrame frame =  new JFrame();
////			getContentPane().add(frame);		
//			ImageIcon icon = new ImageIcon("image/검정.png");
//			JLabel lbl = new JLabel(icon, JLabel.LEFT);
//			lbl.setText("ㅁ");
//			lbl.setIcon(icon);
//			JTextField textField = new JTextField(50);
//			lbl.add(textField);
//			frame.setTitle("당첨 확인 화면");
//			frame.add(lbl);
//			
//			
//			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//			frame.setLocation(200, 200);
//			frame.setSize(500, 300);
////			frame.setVisible(true);