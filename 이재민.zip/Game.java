
public class Game {

public static void main(String[] args) {
	
	GamePlay play = new GamePlay();
	play.GameStart();
}
}
