import java.util.Random;
import java.util.Scanner;

public class Dungeon {

	public void Fighting(HeroStat h, MonsterStat m) {
		System.out.println("\n====================================");
		System.out.println("          던전에 진입하였습니다.       ");
		System.out.println("====================================");
		System.out.println("몬스터와 만났습니다!!");
		System.out.println("전투 시작!!");
		System.out.println("====================================\n");
		m.showHeroStat(); // 몬스터 스탯 보여줌
		Attack attack = new Attack(); // 어택 클래스 호출
		Heal heal = new Heal();
		Random r = new Random();
		
		outer: while (true) {

			System.out.println("\n====================================");
			System.out.println("   선택하세요:                ");
			System.out.println("      1. 공격  2. 회복  3. 도주      ");
			System.out.println("====================================");
			System.out.print("입력 : ");

			Scanner sc = new Scanner(System.in);
			int choose = sc.nextInt();

			switch (choose) {
			case 1:
				m.m_hp = attack.HeroAttack(h, m);
				if (m.m_hp > 0)// 몬스터 체력이 0보다 많을 때 몬스터 공격 실행
					h.hp = attack.MonsterAttack(h, m);

				if (h.hp <= 0) {//용사 체력이 0일 때 던전 반복문을 탈출
					break outer;
				} else if (m.m_hp <= 0) { //몬스터 체력이 0 이하일 때 승리
					System.out.println("\n====================================");
					System.out.println("       몬스터가 쓰러졌습니다!       ");
					System.out.println("             - 전투 승리 -           ");
					System.out.println("====================================\n");
					h.killCount++;
					int rewardRate = r.nextInt(3) + 1;
					System.out.println("====================================");
					System.out.println("       보상을 선택하세요.(1번/2번/3번)       ");
					System.out.println("====================================");
					System.out.print("입력 : ");
					
					int reward1 = rewardRate * 10;
					int reward2 = rewardRate * 20;
					int reward3 = rewardRate * 30;
					
					int rewardChoose = sc.nextInt();
					switch (rewardChoose) {
					case 1:
						h.money += reward1;
						System.out.println(reward1 + " Gold를 획득하였습니다.");
						break;
					case 2:
						h.money += reward2;
						System.out.println(reward2 + " Gold를 획득하였습니다.");
						break;
					case 3:
						h.money += reward3;
						System.out.println(reward3 + " Gold를 획득하였습니다.");
						break;
					default:
						System.out.println("올바른 번호가 아니므로 자동으로 선택됩니다.");
						System.out.println(reward2 + " Gold를 획득하였습니다.");
						h.money += reward2;
						break;
					}
					break outer;

				} else {
//					h.showHeroStat();
//					m.showHeroStat();
					break;
				}

			case 2: //힐을 선택한 경우 Heal 객체를 불러와 힐을 사용
				heal.HeroHeal(h); // 힐 메소드 사용
				h.hp = attack.MonsterAttack(h, m); // 몬스터 공격
				//h.showHeroStat();
				break;
				
			case 3:
				int runRate = r.nextInt(10);
				if (runRate > 3) {
					System.out.println("\n====================================");
					System.out.println("         도주에 성공했습니다.       ");
					System.out.println("====================================\n");
					break outer;
				} else {
					System.out.println("\n====================================");
					System.out.println("         도주에 실패했습니다.       ");
					System.out.println("====================================\n");
					h.hp = attack.MonsterAttack(h, m);
					if (h.hp <= 0) {
						break outer;
					}
					break;
				}
			default:
				System.out.println("올바른 번호를 입력하세요");
				break;
			}

		}
	}
}
