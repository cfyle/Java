import java.util.Random;

//몬스터 스탯
public class MonsterStat {
	Random r = new Random();
	// 체력은 6~11, 공격력은 3~7 랜덤으로 생성
	int m_hp=r.nextInt(5)+6; 
	//int m_hp=7;
	int m_mp;
	int m_at=r.nextInt(3)+3;
	//int m_at=20;
	int m_am=1;
	int m_sk1;

	public void showHeroStat() { // 현재 상태 확인
		System.out.println("<몬스터의 현재 상태>");
		System.out.println("<체력 : " + m_hp + ">");
		System.out.println("<공격력 : " + m_at + ">");
		System.out.println("<방어력 : " + m_am + ">");
	}
}
