//용사 클래스
public class HeroStat {
	String name; //용사의 스탯
	int hp;
	int mp;
	int at;
	int am;
	int killCount = 0;
	int money = 0;
	
	// 용사의 기본 세팅
	public void HeroFirstSetting() {
		hp = 20;
		mp = 20;
		at = 5;
		am = 2;
	}

	// 게임 오버 조건
	public boolean gameOver(int hp) {
		if (hp <= 0) {
			System.out.println("\n====================================");
			System.out.println("용사가 사망하였습니다.");
			System.out.println("Game Over");
			System.out.println("총 잡은 몬스터 수 : " + killCount);
			System.out.println("\n====================================");
			return false;
		} else
			return true;

	}

	// 현재 상태 확인
	public void showHeroStat() {
		System.out.println("[" + name + "의 현재 상태]");
		System.out.println("[체력 : " + hp +"]");
		System.out.println("[마나 : " + mp +"]");
		System.out.println("[공격력 : " + at +"]");
		System.out.println("[방어력 : " + am +"]");
		System.out.println("[돈 : " + money +" Gold]");
	}
}
