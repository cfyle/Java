// 회복 클래스
public class Heal {

	public void HeroHeal(HeroStat h) {
		if (h.mp >= 5) { // 마나가 5 이상일 때
			if (h.hp < 10) { // 체력이 10 이하일 때는 10을 회복
				h.hp += 10;
			} else {// 아닐 경우는 최대 체력으로 회복
				h.hp = 20;
			}
			h.mp -= 5;
			System.out.println("회복 스킬을 사용했습니다.");
			System.out.printf("HP(+10)/MP(-5) (현재 HP : %d)\n", h.hp);
			System.out.println("※ 최대 체력 이상으로는 회복 되지 않습니다.");
			System.out.println("====================================");
		} else {
			System.out.println("====================================");
			System.out.println("마나가 부족합니다.");
			System.out.println("====================================");
		}

	}

}
