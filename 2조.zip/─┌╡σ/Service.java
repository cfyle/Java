package HotelDance;

public class Service {
	boolean breakFast;
	boolean parking;
	boolean restaurant;

	public Service(boolean breakFast, boolean parking, boolean restaurant) {
		super();
		this.breakFast = breakFast;
		this.parking = parking;
		this.restaurant = restaurant;
	}
}